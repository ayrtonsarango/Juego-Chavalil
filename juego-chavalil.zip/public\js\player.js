/**
 * PLAYER CONTROLLER - MANDO MÓVIL
 * Personalizador de Avatar South Park, mandos de J1, soundboard de reacciones y controles.
 */

const socket = io();
window.socket = socket;

// Saved preferences or defaults
const savedName = localStorage.getItem('chaval_name');
const matchedPreset = (typeof AVATAR_PRESETS !== 'undefined')
  ? (AVATAR_PRESETS.find(p => p.name.toLowerCase() === (savedName || '').toLowerCase()) || null)
  : null;

let selectedPresetId = matchedPreset ? matchedPreset.id : 'random';
let currentAvatar = matchedPreset
  ? JSON.parse(JSON.stringify(matchedPreset.config))
  : getRandomAvatar();
let myPlayerId = null;
let isJoined = false;
function detectIsAndroid() {
  const ua = (navigator.userAgent || navigator.vendor || window.opera || '').toLowerCase();
  if (ua.includes('android')) return true;
  if (navigator.userAgentData?.platform?.toLowerCase()?.includes('android')) return true;
  return false;
}
let isAndroidDevice = detectIsAndroid();

let lastHeatData = null;
let currentMinigameType = 'race';

function showActiveGamepad(gType) {
  const padRace = document.getElementById('pad-race');
  const padSmash = document.getElementById('pad-smash');
  const padCurve = document.getElementById('pad-curve');
  const padTank = document.getElementById('pad-tank');
  const padHead = document.getElementById('pad-headsoccer');
  const padBomb = document.getElementById('pad-bomberman');
  const padHax = document.getElementById('pad-haxball');

  const pads = [padRace, padSmash, padCurve, padTank, padHead, padBomb, padHax];
  pads.forEach(p => { if (p) p.style.display = 'none'; });

  if (gType === 'curve') {
    if (padCurve) padCurve.style.display = 'flex';
  } else if (gType === 'tank') {
    if (padTank) padTank.style.display = 'flex';
  } else if (gType === 'headsoccer') {
    if (padHead) padHead.style.display = 'flex';
  } else if (gType === 'bomberman') {
    if (padBomb) padBomb.style.display = 'flex';
  } else if (gType === 'haxball') {
    if (padHax) padHax.style.display = 'flex';
  } else if (gType === 'brawler' || gType === 'smash') {
    if (padSmash) padSmash.style.display = 'flex';
  } else {
    if (padRace) padRace.style.display = 'flex';
  }
}
const screenCreator = document.getElementById('screen-creator');
const screenController = document.getElementById('screen-controller');
const previewAvatarBox = document.getElementById('preview-avatar-box');
const inputPlayerName = document.getElementById('input-player-name');
const btnRandomAvatar = document.getElementById('btn-random-avatar');
const creatorTabs = document.getElementById('creator-tabs');
const optionsScroller = document.getElementById('options-scroller');
const checkAndroidSim = document.getElementById('check-android-sim');
const btnToggleReady = document.getElementById('btn-toggle-ready');
const readyStatusBanner = document.getElementById('ready-status-banner');
const nameValidationMsg = document.getElementById('name-validation-msg');
let isPlayerReady = false;

// Controller screen elements
const playerTopBadge = document.getElementById('player-top-badge');
const controllerAvatarThumb = document.getElementById('controller-avatar-thumb');
const controllerPlayerName = document.getElementById('controller-player-name');
const controllerRoleBadge = document.getElementById('controller-role-badge');
const controllerDeviceBadge = document.getElementById('controller-device-badge');
const boxAndroidMeme = document.getElementById('box-android-meme');
const boxJ1Controls = document.getElementById('box-j1-controls');
const btnJ1StartGame = document.getElementById('btn-j1-start-game');
const boxPlayerMapNav = document.getElementById('box-player-map-nav');
const playerMyNodeBadge = document.getElementById('player-my-node-badge');
const btnPlayerMovePrev = document.getElementById('btn-player-move-prev');
const btnPlayerMoveNext = document.getElementById('btn-player-move-next');
const gatherCount = document.getElementById('gather-count');
const j1MapActions = document.getElementById('j1-map-actions');
const btnJ1EnterLevel = document.getElementById('btn-j1-enter-level');
const btnJ1GatherAll = document.getElementById('btn-j1-gather-all');
const boxMinigameControls = document.getElementById('box-minigame-controls');
const minigameTeamBanner = document.getElementById('minigame-team-banner');

// Pre-fill name if stored or match preset name, otherwise random chaval name
const defaultRandomName = `Chaval_${Math.floor(Math.random() * 90 + 10)}`;
inputPlayerName.value = savedName || (matchedPreset ? matchedPreset.name : defaultRandomName);

// Check Android default
if (isAndroidDevice) {
  checkAndroidSim.checked = true;
}

let activeGlobalTab = 'handItem';

// Preset chips scroller & specific customizer elements
const presetChipsScroll = document.getElementById('preset-chips-scroll');
const characterSpecificBox = document.getElementById('character-specific-box');
const characterSpecificTitle = document.getElementById('character-specific-title');
const specificOptionsContainer = document.getElementById('specific-options-container');

function initPresetChips() {
  if (!presetChipsScroll || typeof AVATAR_PRESETS === 'undefined') return;
  presetChipsScroll.innerHTML = '';

  // 1. Dedicated Random Chip at the start
  const randBtn = document.createElement('button');
  randBtn.className = `preset-chip-btn chip-random ${selectedPresetId === 'random' ? 'active' : ''}`;
  randBtn.textContent = '🎲 Aleatorio';
  randBtn.addEventListener('click', () => {
    if (isPlayerReady) return;
    document.querySelectorAll('.preset-chip-btn').forEach(b => b.classList.remove('active'));
    randBtn.classList.add('active');
    selectedPresetId = 'random';
    currentAvatar = getRandomAvatar();
    const randName = `Chaval_${Math.floor(Math.random() * 90 + 10)}`;
    inputPlayerName.value = randName;
    localStorage.setItem('chaval_name', randName);
    updateAvatarPreview();
    renderCharacterSpecificOptions();
    renderGlobalTabOptions(activeGlobalTab);

    socket.emit('player_toggle_ready', {
      ready: false,
      name: randName,
      avatar: currentAvatar,
      isAndroid: checkAndroidSim.checked || isAndroidDevice
    });
  });
  presetChipsScroll.appendChild(randBtn);

  // 2. Character presets
  AVATAR_PRESETS.forEach((preset) => {
    const btn = document.createElement('button');
    btn.className = `preset-chip-btn ${selectedPresetId === preset.id ? 'active' : ''}`;
    btn.textContent = preset.chip || preset.name;
    btn.addEventListener('click', () => {
      if (isPlayerReady) return;
      document.querySelectorAll('.preset-chip-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedPresetId = preset.id;
      currentAvatar = JSON.parse(JSON.stringify(preset.config));
      inputPlayerName.value = preset.name;
      localStorage.setItem('chaval_name', preset.name);
      updateAvatarPreview();
      renderCharacterSpecificOptions();
      renderGlobalTabOptions(activeGlobalTab);

      // Reproducir sonido temático del personaje en el móvil y en la pantalla grande
      if (window.soundEngine) {
        soundEngine.playCharacterTheme(preset.id, preset.name);
      }
      socket.emit('player_character_selected', {
        characterId: preset.id,
        characterName: preset.name
      });

      socket.emit('player_toggle_ready', {
        ready: false,
        name: preset.name,
        avatar: currentAvatar,
        isAndroid: checkAndroidSim.checked || isAndroidDevice
      });
    });
    presetChipsScroll.appendChild(btn);
  });
}

// 1. Render Avatar Preview
function updateAvatarPreview() {
  const avatarSvg = renderAvatarSVG(currentAvatar, 120);
  const petSvg = currentAvatar.pet && currentAvatar.pet !== 'none' ? renderPetSVG(currentAvatar.pet, 56) : '';

  previewAvatarBox.innerHTML = `
    <div style="display: flex; align-items: flex-end; justify-content: center; gap: 6px;">
      <div>${avatarSvg}</div>
      ${petSvg ? `<div class="preview-pet-wrap" style="animation: bounce 1.8s infinite ease-in-out; filter: drop-shadow(0 4px 8px rgba(0,0,0,0.4));">${petSvg}</div>` : ''}
    </div>
  `;
}

// 2. Render Character-Specific Options (Toggles binarios directos, sin placeholders innecesarios)
function renderCharacterSpecificOptions() {
  if (!specificOptionsContainer || typeof CHARACTER_SPECIFIC_OPTIONS === 'undefined') return;
  specificOptionsContainer.innerHTML = '';

  const specToggles = CHARACTER_SPECIFIC_OPTIONS[selectedPresetId] || [];
  if (specToggles.length === 0) {
    if (characterSpecificBox) characterSpecificBox.style.display = 'none';
    return;
  }

  if (characterSpecificBox) characterSpecificBox.style.display = 'block';

  const rowEl = document.createElement('div');
  rowEl.className = 'specific-toggles-row';

  specToggles.forEach(toggle => {
    const isActive = currentAvatar[toggle.prop] === toggle.on;
    const btn = document.createElement('button');
    btn.className = `toggle-pill ${isActive ? 'active' : ''} ${isPlayerReady ? 'is-locked' : ''}`;
    btn.innerHTML = `<span class="toggle-indicator">${isActive ? '🟢' : '⚪'}</span> <span>${toggle.label}</span>`;
    btn.addEventListener('click', () => {
      if (isPlayerReady) return;
      const willBeActive = currentAvatar[toggle.prop] !== toggle.on;
      currentAvatar[toggle.prop] = willBeActive ? toggle.on : toggle.off;
      if (typeof toggle.sideEffect === 'function') {
        toggle.sideEffect(currentAvatar, willBeActive);
      }
      updateAvatarPreview();
      renderCharacterSpecificOptions();
      socket.emit('player_toggle_ready', {
        ready: false,
        name: inputPlayerName.value.trim() || 'Chaval',
        avatar: currentAvatar,
        isAndroid: checkAndroidSim.checked || isAndroidDevice
      });
    });
    rowEl.appendChild(btn);
  });

  specificOptionsContainer.appendChild(rowEl);
}

// 3. Render Global Tab Options (En Mano & Mascota)
function renderGlobalTabOptions(tabKey) {
  activeGlobalTab = tabKey;
  if (!optionsScroller) return;
  optionsScroller.innerHTML = '';

  if (tabKey === 'handItem') {
    (AVATAR_OPTIONS.handItems || []).forEach(opt => {
      const pill = document.createElement('button');
      const isSelected = (currentAvatar.handItem || 'none') === opt.id;
      pill.className = `pill-option ${isSelected ? 'active' : ''} ${isPlayerReady ? 'is-locked' : ''}`;
      pill.innerHTML = `<span>${opt.icon || '✋'}</span> <span>${opt.label}</span>`;
      pill.title = opt.desc || opt.label;
      pill.addEventListener('click', () => {
        if (isPlayerReady) return;
        currentAvatar.handItem = opt.id;
        updateAvatarPreview();
        renderGlobalTabOptions('handItem');
        socket.emit('player_toggle_ready', {
          ready: false,
          name: inputPlayerName.value.trim() || 'Chaval',
          avatar: currentAvatar,
          isAndroid: checkAndroidSim.checked || isAndroidDevice
        });
      });
      optionsScroller.appendChild(pill);
    });
  } else if (tabKey === 'pet') {
    (AVATAR_OPTIONS.pets || []).forEach(opt => {
      const pill = document.createElement('button');
      const isSelected = (currentAvatar.pet || 'none') === opt.id;
      pill.className = `pill-option pill-pet ${isSelected ? 'active' : ''} ${isPlayerReady ? 'is-locked' : ''}`;
      pill.innerHTML = `<span>${opt.icon}</span> <span>${opt.label}</span>`;
      pill.title = opt.desc || opt.breed || opt.label;
      pill.addEventListener('click', () => {
        if (isPlayerReady) return;
        currentAvatar.pet = opt.id;
        updateAvatarPreview();
        renderGlobalTabOptions('pet');
        socket.emit('player_toggle_ready', {
          ready: false,
          name: inputPlayerName.value.trim() || 'Chaval',
          avatar: currentAvatar,
          isAndroid: checkAndroidSim.checked || isAndroidDevice
        });
      });
      optionsScroller.appendChild(pill);
    });
  }
}

// Tab Buttons click
if (creatorTabs) {
  creatorTabs.addEventListener('click', (e) => {
    if (isPlayerReady) return;
    const btn = e.target.closest('.tab-btn');
    if (btn) {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderGlobalTabOptions(btn.dataset.tab);
    }
  });
}

// Function to update UI locking state based on isPlayerReady
function setPlayerReadyUI(ready) {
  isPlayerReady = ready;
  if (isPlayerReady) {
    if (btnToggleReady) {
      btnToggleReady.innerHTML = '↩️ Deshacer Listo (Modificar)';
      btnToggleReady.className = 'btn btn-warning btn-big-action';
    }
    if (readyStatusBanner) readyStatusBanner.style.display = 'block';
    if (inputPlayerName) inputPlayerName.disabled = true;
    if (checkAndroidSim) checkAndroidSim.disabled = true;
    if (btnRandomAvatar) btnRandomAvatar.classList.add('is-locked');
    document.querySelectorAll('.preset-chip-btn, .pill-option, .tab-btn').forEach(el => el.classList.add('is-locked'));
  } else {
    if (btnToggleReady) {
      btnToggleReady.innerHTML = '✅ ¡LISTO PARA JUGAR!';
      btnToggleReady.className = 'btn btn-success btn-big-action';
    }
    if (readyStatusBanner) readyStatusBanner.style.display = 'none';
    if (inputPlayerName) inputPlayerName.disabled = false;
    if (checkAndroidSim) checkAndroidSim.disabled = false;
    if (btnRandomAvatar) btnRandomAvatar.classList.remove('is-locked');
    document.querySelectorAll('.preset-chip-btn, .pill-option, .tab-btn').forEach(el => el.classList.remove('is-locked'));
  }
}

// Nickname Live Validation & Sync
if (inputPlayerName) {
  inputPlayerName.addEventListener('input', () => {
    const name = (inputPlayerName.value || '').trim();
    if (name.length < 2 || name.length > 15) {
      if (nameValidationMsg) nameValidationMsg.style.display = 'block';
    } else {
      if (nameValidationMsg) nameValidationMsg.style.display = 'none';
      localStorage.setItem('chaval_name', name);
      socket.emit('player_toggle_ready', {
        ready: isPlayerReady,
        name,
        avatar: currentAvatar,
        isAndroid: checkAndroidSim.checked || isAndroidDevice
      });
    }
  });
}

// Android simulator checkbox change
if (checkAndroidSim) {
  checkAndroidSim.addEventListener('change', () => {
    if (isPlayerReady) return;
    const isAndroid = checkAndroidSim.checked || isAndroidDevice;
    socket.emit('player_toggle_ready', {
      ready: isPlayerReady,
      name: (inputPlayerName.value || '').trim() || 'Chaval',
      avatar: currentAvatar,
      isAndroid
    });
  });
}

// Toggle Ready Button click
if (btnToggleReady) {
  btnToggleReady.addEventListener('click', () => {
    const name = (inputPlayerName.value || '').trim();
    if (name.length < 2 || name.length > 15) {
      if (nameValidationMsg) nameValidationMsg.style.display = 'block';
      inputPlayerName.focus();
      return;
    }
    if (nameValidationMsg) nameValidationMsg.style.display = 'none';

    localStorage.setItem('chaval_name', name);
    const nextReady = !isPlayerReady;
    setPlayerReadyUI(nextReady);

    const isAndroid = checkAndroidSim.checked || isAndroidDevice;
    socket.emit('player_toggle_ready', {
      ready: isPlayerReady,
      name,
      avatar: currentAvatar,
      isAndroid
    });

    // El sonido temático del personaje asignado se reproduce al darle a LISTO
    if (nextReady) {
      if (window.soundEngine) {
        soundEngine.playCharacterTheme(selectedPresetId, name);
      }
      socket.emit('player_character_selected', {
        characterId: selectedPresetId,
        characterName: name
      });

      // Si es Android, reproducir también la bocina goofy de Android detectado en el móvil y en el admin
      if (isAndroid) {
        setTimeout(() => {
          if (window.soundEngine) soundEngine.playAndroidAlert();
        }, 600);
        socket.emit('android_ready_alert', {
          playerName: name,
          characterId: selectedPresetId
        });
      }
    }
  });
}

// Auto-register on socket connection
function sendCurrentRegistration(ready = isPlayerReady) {
  const name = (inputPlayerName.value || '').trim() || 'Chaval';
  const isAndroid = checkAndroidSim.checked || isAndroidDevice;
  socket.emit('player_join', {
    name,
    avatar: currentAvatar,
    isAndroid,
    ready
  });
}

socket.on('connect', () => {
  sendCurrentRegistration(isPlayerReady);
});

socket.on('player_kicked', (data) => {
  alert(data?.reason || 'Has sido expulsado por el Administrador.');
  window.location.reload();
});

// Update Mobile Controller View according to state
function updateControllerState(gameState, players) {
  const me = players.find(p => p.id === socket.id);
  if (!me) return;

  // View routing based on gameState.status
  if (gameState.status === 'map' || gameState.status === 'minigame') {
    screenCreator.classList.remove('active');
    screenController.classList.add('active');
    if (playerTopBadge) playerTopBadge.style.display = 'inline-flex';
  } else {
    // In lobby: keep creator active so players can modify avatar/toggle ready
    screenController.classList.remove('active');
    screenCreator.classList.add('active');
    if (me.ready !== isPlayerReady) {
      setPlayerReadyUI(Boolean(me.ready));
    }
  }

  // Header meta
  controllerAvatarThumb.innerHTML = renderAvatarSVG(me.avatar, 50);
  controllerPlayerName.textContent = me.name;

  if (me.isJ1) {
    controllerRoleBadge.textContent = '👑 J1 (Líder)';
    controllerRoleBadge.className = 'badge badge-j1';
  } else {
    controllerRoleBadge.textContent = 'Jugador';
    controllerRoleBadge.className = 'badge';
  }

  if (me.isAndroid) {
    controllerDeviceBadge.textContent = '🤖 Android';
    controllerDeviceBadge.className = 'badge badge-android';
    boxAndroidMeme.style.display = 'block';
  } else {
    controllerDeviceBadge.textContent = '🍏 iOS';
    controllerDeviceBadge.className = 'badge badge-ios';
    boxAndroidMeme.style.display = 'none';
  }

  let myCurrentMapNode = 0;

  // Adjust J1 & Map Navigation visibility by game status
  if (gameState.status === 'lobby') {
    if (boxJ1Controls) boxJ1Controls.style.display = me.isJ1 ? 'block' : 'none';
    if (btnJ1StartGame) btnJ1StartGame.style.display = 'none'; // El Admin inicia la partida desde el host
    if (boxPlayerMapNav) boxPlayerMapNav.style.display = 'none';
    if (boxMinigameControls) boxMinigameControls.style.display = 'none';
  } else if (gameState.status === 'podium') {
    if (boxJ1Controls) boxJ1Controls.style.display = 'none';
    if (btnJ1StartGame) btnJ1StartGame.style.display = 'none';
    if (boxPlayerMapNav) boxPlayerMapNav.style.display = 'none';
    if (j1MapActions) j1MapActions.style.display = 'none';
    if (boxMinigameControls) boxMinigameControls.style.display = 'none';
  } else if (gameState.status === 'map') {
    if (boxJ1Controls) boxJ1Controls.style.display = 'none';
    if (btnJ1StartGame) btnJ1StartGame.style.display = 'none';
    if (boxMinigameControls) boxMinigameControls.style.display = 'none';
    if (boxPlayerMapNav) boxPlayerMapNav.style.display = 'block';
    if (j1MapActions) j1MapActions.style.display = me.isJ1 ? 'flex' : 'none';

    // Player node display & level lock progression
    const myNode = (gameState.playerPositions && gameState.playerPositions[me.id] !== undefined)
      ? gameState.playerPositions[me.id]
      : (myCurrentMapNode || 0);
    myCurrentMapNode = myNode;
    if (playerMyNodeBadge) {
      playerMyNodeBadge.textContent = `📍 Mi posición: Mundo 1-${myNode + 1}`;
    }

    const maxUnlocked = typeof gameState.maxUnlockedNode === 'number' ? gameState.maxUnlockedNode : 0;
    if (btnPlayerMoveNext) {
      if (myCurrentMapNode >= maxUnlocked) {
        btnPlayerMoveNext.disabled = true;
        btnPlayerMoveNext.style.opacity = '0.5';
        btnPlayerMoveNext.style.cursor = 'not-allowed';
        btnPlayerMoveNext.innerHTML = '🔒 Bloqueado';
      } else {
        btnPlayerMoveNext.disabled = false;
        btnPlayerMoveNext.style.opacity = '1';
        btnPlayerMoveNext.style.cursor = 'pointer';
        btnPlayerMoveNext.innerHTML = 'Siguiente ➡️';
      }
    }
    if (btnPlayerMovePrev) {
      if (myCurrentMapNode <= 0) {
        btnPlayerMovePrev.disabled = true;
        btnPlayerMovePrev.style.opacity = '0.5';
        btnPlayerMovePrev.style.cursor = 'not-allowed';
      } else {
        btnPlayerMovePrev.disabled = false;
        btnPlayerMovePrev.style.opacity = '1';
        btnPlayerMovePrev.style.cursor = 'pointer';
      }
    }
  } else if (gameState.status === 'minigame') {
    if (boxJ1Controls) boxJ1Controls.style.display = 'none';
    if (btnJ1StartGame) btnJ1StartGame.style.display = 'none';
    if (boxPlayerMapNav) boxPlayerMapNav.style.display = 'none';
    if (j1MapActions) j1MapActions.style.display = 'none';
    if (boxMinigameControls) boxMinigameControls.style.display = 'flex';

    // Find my team
    const teamA = gameState.teams?.teamA || [];
    const inTeamA = teamA.some(p => p.id === me.id);

    if (inTeamA) {
      minigameTeamBanner.textContent = '🔵 TU EQUIPO: AZUL';
      minigameTeamBanner.style.background = '#1e3a8a';
      minigameTeamBanner.style.color = '#93c5fd';
    } else {
      minigameTeamBanner.textContent = '🔴 TU EQUIPO: ROJO';
      minigameTeamBanner.style.background = '#7f1d1d';
      minigameTeamBanner.style.color = '#fca5a5';
    }

    const boxBench = document.getElementById('box-bench-spectator');
    currentMinigameType = gameState.minigameActive?.gameType || (gameState.currentLevelIndex === 0 ? 'race' : 'brawler');

    if (lastHeatData && lastHeatData.activePlayerIds && !lastHeatData.activePlayerIds.includes(me.id)) {
      if (boxBench) boxBench.style.display = 'flex';
      minigameTeamBanner.textContent = `🛋️ EN EL BANQUILLO (Ronda ${lastHeatData.heatIndex}/${lastHeatData.totalHeats})`;
      const pads = ['pad-race', 'pad-smash', 'pad-curve', 'pad-tank', 'pad-headsoccer', 'pad-bomberman', 'pad-haxball'];
      pads.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
      });
    } else {
      if (boxBench) boxBench.style.display = 'none';
      showActiveGamepad(currentMinigameType);
    }
  } else {
    const boxBench = document.getElementById('box-bench-spectator');
    if (boxBench) boxBench.style.display = 'none';
    lastHeatData = null;
  }
}

// Socket Listeners
socket.on('state_update', (data) => {
  myPlayerId = socket.id;
  updateControllerState(data.gameState, data.players || []);
});

// Pelotón status from server
socket.on('map_peloton_status', (data) => {
  if (data.playerPositions && myPlayerId && data.playerPositions[myPlayerId] !== undefined) {
    if (playerMyNodeBadge) {
      playerMyNodeBadge.textContent = `📍 Mi posición: Mundo 1-${data.playerPositions[myPlayerId] + 1}`;
    }
  }

  if (gatherCount) {
    const atMyNode = data.countsByNode ? (data.countsByNode[data.targetNode !== null ? data.targetNode : 0] || 1) : (data.readyCount || 1);
    gatherCount.textContent = `${data.readyCount || 1} / ${data.totalPlayers || 1}`;
    if (data.allAtNode) {
      gatherCount.style.color = '#4ade80';
    } else {
      gatherCount.style.color = '#60a5fa';
    }
  }

  if (btnJ1EnterLevel) {
    if (data.allAtNode) {
      btnJ1EnterLevel.innerHTML = '✨ ¡PELOTÓN REUNIDO! ENTRAR (1)';
      btnJ1EnterLevel.className = 'btn btn-success btn-big-action';
    } else {
      btnJ1EnterLevel.innerHTML = `🏁 ENTRAR AL NIVEL (${data.readyCount || 1}/${data.totalPlayers || 1})`;
      btnJ1EnterLevel.className = 'btn btn-warning btn-big-action';
    }
  }
});

// Listener when player attempts to advance to a locked level
socket.on('map_move_blocked', (data) => {
  if (navigator.vibrate) navigator.vibrate([60, 40, 60]);
  if (playerMyNodeBadge) {
    const originalText = playerMyNodeBadge.textContent;
    playerMyNodeBadge.textContent = data.reason || '🔒 ¡Nivel bloqueado!';
    playerMyNodeBadge.style.color = '#ef4444';
    setTimeout(() => {
      playerMyNodeBadge.textContent = originalText;
      playerMyNodeBadge.style.color = '#fbbf24';
    }, 2400);
  }
});

// J1 Button Actions
if (btnJ1StartGame) {
  btnJ1StartGame.addEventListener('click', () => {
    socket.emit('start_game');
  });
}

if (btnPlayerMoveNext) {
  btnPlayerMoveNext.addEventListener('click', () => {
    socket.emit('player_move_node', { direction: 'next' });
    if (navigator.vibrate) navigator.vibrate(25);
  });
}

if (btnPlayerMovePrev) {
  btnPlayerMovePrev.addEventListener('click', () => {
    socket.emit('player_move_node', { direction: 'prev' });
    if (navigator.vibrate) navigator.vibrate(25);
  });
}

if (btnJ1GatherAll) {
  btnJ1GatherAll.addEventListener('click', () => {
    socket.emit('map_gather_squad');
    if (navigator.vibrate) navigator.vibrate(40);
  });
}

btnJ1EnterLevel.addEventListener('click', () => {
  socket.emit('map_enter_level');
});

// Soundboard Meme de la Cuadrilla con Cooldown de 4 segundos
let soundboardCooldownActive = false;
let soundboardCooldownTimer = null;
const soundboardCooldownBadge = document.getElementById('soundboard-cooldown-badge');

function triggerSoundboardCooldown(durationMs = 4000) {
  soundboardCooldownActive = true;
  const buttons = document.querySelectorAll('.btn-emote');
  buttons.forEach(b => {
    b.disabled = true;
    b.classList.add('is-cooldown');
  });

  const badges = document.querySelectorAll('.soundboard-cooldown-badge, #soundboard-cooldown-badge');
  let remainingSec = Math.ceil(durationMs / 1000);
  badges.forEach(b => {
    b.style.display = 'inline-block';
    b.textContent = `⏳ ${remainingSec}s`;
  });

  const interval = setInterval(() => {
    remainingSec--;
    if (remainingSec > 0) {
      badges.forEach(b => {
        b.textContent = `⏳ ${remainingSec}s`;
      });
    } else {
      clearInterval(interval);
    }
  }, 1000);

  clearTimeout(soundboardCooldownTimer);
  soundboardCooldownTimer = setTimeout(() => {
    soundboardCooldownActive = false;
    buttons.forEach(b => {
      b.disabled = false;
      b.classList.remove('is-cooldown');
    });
    badges.forEach(b => {
      b.style.display = 'none';
    });
  }, durationMs);
}

document.querySelectorAll('.btn-emote').forEach(btn => {
  btn.addEventListener('click', () => {
    if (soundboardCooldownActive) return;

    btn.classList.add('is-pressed');
    setTimeout(() => btn.classList.remove('is-pressed'), 140);

    const emote = btn.dataset.emote || '📢';
    const soundName = btn.dataset.sound || 'bocina';

    // Reproducir en local
    if (window.soundEngine) {
      soundEngine.playSoundByName(soundName);
    }

    // Emitir a la sala para que suene en la pantalla grande
    socket.emit('player_emote', {
      emote,
      sound: soundName,
      playerName: inputPlayerName.value || 'Chaval'
    });

    // Activar cooldown de 4s
    triggerSoundboardCooldown(4000);

    // Haptic feedback
    if (navigator.vibrate) {
      navigator.vibrate(40);
    }
  });
});

// Socket listeners para eventos del minijuego y temas de personajes
socket.on('character_theme_broadcast', (data) => {
  if (data && window.soundEngine) {
    if (data.playerId !== socket.id) {
      soundEngine.playCharacterTheme(data.characterId, data.characterName || data.playerName);
    }
  }
});

socket.on('minigame_event_broadcast', (data) => {
  if (window.soundEngine) {
    if (data.type === 'kill') {
      soundEngine.playDeathSound(data.isFirst);
    } else if (data.type === 'danger_alarm') {
      soundEngine.playDangerAlarm();
    }
  }
  if (navigator.vibrate) {
    navigator.vibrate([100, 50, 100]);
  }
});

socket.on('level_completed_celebration', () => {
  if (window.soundEngine) {
    soundEngine.playSocialCreditVictory();
  }
  const boxBench = document.getElementById('box-bench-spectator');
  if (boxBench) boxBench.style.display = 'none';
  lastHeatData = null;
});

// Heats & Spectator Mode on Phone
socket.on('minigame_heat_update', (data) => {
  lastHeatData = data;
  const boxBench = document.getElementById('box-bench-spectator');
  const benchHeatStatus = document.getElementById('bench-heat-status');
  const padContainers = ['pad-race', 'pad-smash', 'pad-curve', 'pad-tank', 'pad-headsoccer', 'pad-bomberman', 'pad-haxball'];

  if (!data || !data.activePlayerIds) return;

  const isActive = data.activePlayerIds.includes(myPlayerId);

  if (isActive) {
    if (boxBench) boxBench.style.display = 'none';
    if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
    if (minigameTeamBanner) {
      minigameTeamBanner.textContent = `⚔️ ¡ESTÁS EN LA ARENA! (Ronda ${data.heatIndex}/${data.totalHeats})`;
    }
    showActiveGamepad(currentMinigameType);
  } else {
    if (screenCreator && screenController) {
      screenCreator.classList.remove('active');
      screenController.classList.add('active');
    }
    if (boxMinigameControls) {
      boxMinigameControls.style.display = 'flex';
    }
    if (boxJ1Controls) boxJ1Controls.style.display = 'none';
    if (boxPlayerMapNav) boxPlayerMapNav.style.display = 'none';

    if (boxBench) {
      boxBench.style.display = 'flex';
      if (benchHeatStatus) {
        benchHeatStatus.textContent = `Ronda ${data.heatIndex}/${data.totalHeats} en juego. ¡Prepárate para la siguiente!`;
      }
    }
    if (minigameTeamBanner) {
      minigameTeamBanner.textContent = `🛋️ EN EL BANQUILLO (Ronda ${data.heatIndex}/${data.totalHeats})`;
    }
    padContainers.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
  }
});

// Bench Spectator Cheer Reactions
document.querySelectorAll('.btn-bench-cheer').forEach(btn => {
  btn.addEventListener('click', () => {
    btn.classList.add('is-pressed');
    setTimeout(() => btn.classList.remove('is-pressed'), 140);

    const cheer = btn.dataset.cheer || '👏';
    const text = btn.dataset.cheerText || '¡VAMOOOS!';
    const sound = btn.dataset.cheerSound || 'mario_coin';

    if (window.soundEngine) {
      soundEngine.playMarioCoin();
    }
    socket.emit('player_emote', {
      emote: cheer,
      sound,
      playerName: `${inputPlayerName.value || 'Chaval'} (${text})`
    });
    if (navigator.vibrate) navigator.vibrate(35);
  });
});

// Interactive Minigame Touch Gamepad Helpers (Mario Kart & Super Smash Bros)
function bindHoldButton(el, onDown, onUp) {
  if (!el) return;
  const start = (e) => {
    e.preventDefault();
    el.classList.add('is-pressed');
    if (navigator.vibrate) navigator.vibrate(25);
    onDown();
  };
  const end = (e) => {
    e.preventDefault();
    el.classList.remove('is-pressed');
    onUp();
  };
  el.addEventListener('pointerdown', start);
  el.addEventListener('pointerup', end);
  el.addEventListener('pointercancel', end);
  el.addEventListener('pointerleave', end);
}

function bindTapButton(el, onTap) {
  if (!el) return;
  el.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    el.classList.add('is-pressed');
    if (navigator.vibrate) navigator.vibrate(35);
    onTap();
    setTimeout(() => el.classList.remove('is-pressed'), 120);
  });
}

// 1. Mario Kart Mobile Bindings
bindHoldButton(document.getElementById('btn-kart-left'),
  () => socket.emit('player_input', { steer: -1 }),
  () => socket.emit('player_input', { steer: 0 })
);
bindHoldButton(document.getElementById('btn-kart-right'),
  () => socket.emit('player_input', { steer: 1 }),
  () => socket.emit('player_input', { steer: 0 })
);
bindHoldButton(document.getElementById('btn-kart-gas'),
  () => socket.emit('player_input', { gas: true }),
  () => socket.emit('player_input', { gas: false })
);
bindHoldButton(document.getElementById('btn-kart-drift'),
  () => socket.emit('player_input', { drift: true }),
  () => socket.emit('player_input', { drift: false })
);
bindTapButton(document.getElementById('btn-kart-item'),
  () => socket.emit('player_input', { item: true })
);

// 2. Super Smash Bros Mobile Bindings
bindHoldButton(document.getElementById('btn-smash-left'),
  () => socket.emit('player_input', { left: true }),
  () => socket.emit('player_input', { left: false })
);
bindHoldButton(document.getElementById('btn-smash-right'),
  () => socket.emit('player_input', { right: true }),
  () => socket.emit('player_input', { right: false })
);
bindHoldButton(document.getElementById('btn-smash-up'),
  () => socket.emit('player_input', { up: true }),
  () => socket.emit('player_input', { up: false })
);
bindHoldButton(document.getElementById('btn-smash-down'),
  () => socket.emit('player_input', { down: true }),
  () => socket.emit('player_input', { down: false })
);
bindTapButton(document.getElementById('btn-smash-attack'),
  () => socket.emit('player_input', { attack: true })
);
bindTapButton(document.getElementById('btn-smash-special'),
  () => socket.emit('player_input', { special: true })
);
bindHoldButton(document.getElementById('btn-smash-shield'),
  () => socket.emit('player_input', { shield: true }),
  () => socket.emit('player_input', { shield: false })
);

// 3. Curve Fever Mobile Bindings
bindHoldButton(document.getElementById('btn-curve-left'),
  () => socket.emit('player_input', { left: true }),
  () => socket.emit('player_input', { left: false })
);
bindHoldButton(document.getElementById('btn-curve-right'),
  () => socket.emit('player_input', { right: true }),
  () => socket.emit('player_input', { right: false })
);

// 4. Tank Trouble Mobile Bindings
bindHoldButton(document.getElementById('btn-tank-up'),
  () => socket.emit('player_input', { up: true }),
  () => socket.emit('player_input', { up: false })
);
bindHoldButton(document.getElementById('btn-tank-down'),
  () => socket.emit('player_input', { down: true }),
  () => socket.emit('player_input', { down: false })
);
bindHoldButton(document.getElementById('btn-tank-left'),
  () => socket.emit('player_input', { left: true }),
  () => socket.emit('player_input', { left: false })
);
bindHoldButton(document.getElementById('btn-tank-right'),
  () => socket.emit('player_input', { right: true }),
  () => socket.emit('player_input', { right: false })
);
bindTapButton(document.getElementById('btn-tank-fire'),
  () => socket.emit('player_input', { fire: true })
);

// 5. Head Soccer Mobile Bindings
bindHoldButton(document.getElementById('btn-head-left'),
  () => socket.emit('player_input', { left: true }),
  () => socket.emit('player_input', { left: false })
);
bindHoldButton(document.getElementById('btn-head-right'),
  () => socket.emit('player_input', { right: true }),
  () => socket.emit('player_input', { right: false })
);
bindHoldButton(document.getElementById('btn-head-jump'),
  () => socket.emit('player_input', { up: true }),
  () => socket.emit('player_input', { up: false })
);
bindTapButton(document.getElementById('btn-head-kick'),
  () => socket.emit('player_input', { kick: true })
);

// 6. Bomberman Mobile Bindings
bindHoldButton(document.getElementById('btn-bomb-up'),
  () => socket.emit('player_input', { up: true }),
  () => socket.emit('player_input', { up: false })
);
bindHoldButton(document.getElementById('btn-bomb-down'),
  () => socket.emit('player_input', { down: true }),
  () => socket.emit('player_input', { down: false })
);
bindHoldButton(document.getElementById('btn-bomb-left'),
  () => socket.emit('player_input', { left: true }),
  () => socket.emit('player_input', { left: false })
);
bindHoldButton(document.getElementById('btn-bomb-right'),
  () => socket.emit('player_input', { right: true }),
  () => socket.emit('player_input', { right: false })
);
bindTapButton(document.getElementById('btn-bomb-drop'),
  () => socket.emit('player_input', { bomb: true })
);

// 7. HaxBall Mobile Bindings
bindHoldButton(document.getElementById('btn-hax-up'),
  () => socket.emit('player_input', { up: true }),
  () => socket.emit('player_input', { up: false })
);
bindHoldButton(document.getElementById('btn-hax-down'),
  () => socket.emit('player_input', { down: true }),
  () => socket.emit('player_input', { down: false })
);
bindHoldButton(document.getElementById('btn-hax-left'),
  () => socket.emit('player_input', { left: true }),
  () => socket.emit('player_input', { left: false })
);
bindHoldButton(document.getElementById('btn-hax-right'),
  () => socket.emit('player_input', { right: true }),
  () => socket.emit('player_input', { right: false })
);
bindTapButton(document.getElementById('btn-hax-kick'),
  () => socket.emit('player_input', { kick: true })
);

// Fallback keyboard on phone / browser
window.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') socket.emit('player_input', { steer: -1, left: true });
  if (e.key === 'ArrowRight') socket.emit('player_input', { steer: 1, right: true });
  if (e.key === 'ArrowUp' || e.key === ' ') socket.emit('player_input', { gas: true, up: true });
  if (e.key === 'ArrowDown') socket.emit('player_input', { down: true });
  if (e.key === 'z' || e.key === 'j') socket.emit('player_input', { attack: true, item: true, fire: true, kick: true, bomb: true });
  if (e.key === 'x' || e.key === 'k') socket.emit('player_input', { special: true, drift: true, kick: true });
});

window.addEventListener('keyup', (e) => {
  if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') socket.emit('player_input', { steer: 0, left: false, right: false });
  if (e.key === 'ArrowUp' || e.key === ' ') socket.emit('player_input', { gas: false, up: false });
  if (e.key === 'ArrowDown') socket.emit('player_input', { down: false });
  if (e.key === 'x' || e.key === 'k') socket.emit('player_input', { drift: false });
});

// Initial boot
initPresetChips();
renderCharacterSpecificOptions();
updateAvatarPreview();
renderGlobalTabOptions('handItem');

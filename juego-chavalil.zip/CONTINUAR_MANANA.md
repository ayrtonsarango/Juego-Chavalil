# 📋 ESTADO DEL PROYECTO Y GUÍA DE REANUDACIÓN (PARA MAÑANA)

Documento actualizado para que cualquier agente o desarrollador reanude el proyecto sabiendo exactamente qué se hizo, dónde está cada archivo y el estado validado de los 7 minigames y controles.

---

## 🧭 1. Resumen Ejecutivo del Proyecto
- **Proyecto**: *Juego Chavalil* — Party game multijugador web estilo Jackbox + Super Mario World + Mario Kart + Smash Bros.
- **Flujo de Pantallas**:
  1. **Pantalla Principal (Host / TV)**: `http://localhost:3000/host`
     - Lobby con avatares de la cuadrilla y detección de J1.
     - Mapa Overworld 3D interactivo con progresión secuencial estricta (Mundo 1-1 a 1-7).
     - Modo Torneo / Heats para 8-12 jugadores (duelos 1v1 o 2v2 manteniendo legibilidad en TV y acumulando puntos para Equipo Azul vs Rojo).
     - Podio con ganador destacado en el centro y ranking ordenado a la derecha con medallas (🥇, 🥈, 🥉).
  2. **Mando Móvil (Player / Smartphone)**: `http://localhost:3000/player`
     - Creador de avatar South Park con toggles binarios limpios.
     - Mandos táctiles dedicados para cada minijuego a 60 FPS (0 barras de scroll a 412x850).
     - Modo Banquillo / Espectador interactivo para jugadores en espera con 4 botones de ánimos (`👏`, `🔥`, `💀`, `🏆`).
     - Soundboard oficial de 6 memes (`BOCINA`, `AUUUU`, `BING CHILLING`, `FAAAH`, `OH MY GOD`, `ALLAH`).

---

## 🎮 2. Catálogo de los 7 Minijuegos (Ultra Réplicas a 150 FPS)
1. **Super Mario Kart (SNES Mode 7)**: `public/js/minigames/mario-kart.js`
   - Proyección matemática Mode 7 scanline a 60 FPS en pista Mario Circuit 1 (512x512).
   - Fondo parallax Super Mario, karts con rotación de 22 ángulos y avatares.
   - Proyección de partículas 3D (humo, chispas de derrape, fuego de nitro, estrellas).
   - Radar 2D en tiempo real, velocímetro LED digital, vueltas y ruleta de objetos.
2. **Super Smash Bros (Battlefield)**: `public/js/minigames/super-smash.js`
   - Escenario flotante Battlefield con cristales de energía y 3 plataformas suaves.
   - Agarre de bordes (Ledge Grab), Up-B Recuperación (puño de fuego vertical), Meteor Spike aéreo, Escudo burbuja y Shield Break con mareo (`💫`).
   - Destellos cómic de impacto, aura de fuego en alto daño (>100%) y textos de combate.
3. **Sports Heads: Football (Head Soccer)**: `public/js/minigames/head-soccer.js`
   - Duelos 1v1 y 2v2 por rondas acumulando marcador global.
   - Cabezones gigantes con bota animada, física angular de balón con rebotes en postes/larguero.
   - 6 potenciadores flotantes (Fuego, Cabezón, Hielo, Supersalto, Velocidad, Minibalón).
   - Estela de cometa en balón y focos volumétricos de estadio oscilantes.
4. **Curve Fever (Curvytron)**: `public/js/minigames/curve-fever.js`
   - Arena cyber grid, torneo a 3 rondas con 8 curvas simultáneas, huecos y potenciadores.
   - Mando móvil con dos botones gigantes (50% Izquierda / 50% Derecha).
5. **Tank Trouble**: `public/js/minigames/tank-trouble.js`
   - Laberinto procedural con 8 puntos de spawn, proyectiles láser con rebotes, bombas de fragmentación y misiles.
   - Huellas de orugas persistentes que se desvanecen, retroceso de cañón y fogonazos.
6. **Chaval Bomberman**: `public/js/minigames/bomberman.js`
   - Cuadrícula de 15x9 con bloques destruibles, pilares fijos y muerte súbita con bloques que caen.
   - Pulsación rítmica en bombas y escombros al romper cajas.
7. **HaxBall Chavalil (Soccer.js)**: `public/js/minigames/haxball.js`
   - Físicas circulares de disco, estela de cometa sónica en tiros fuertes y confeti en goles.
   - IA táctica con roles asignados (Portero bajo palos, Extremos abiertos y Delantero en centro).

---

## 👥 3. Roster Canónico de los 14 Chavales
- **Ayrton**: Toggle `Cara Loca`. Sonido: `auuu`. Mascota: Bembo.
- **Adriachi**: Gafas siempre. Toggle: `Jordans` (normales vs cómicamente gigantes). Sonido: `50_cent`. Mascota: Coca-Cola Zero.
- **Lerga**: Gafas siempre. Camiseta roja TRACASA default. Toggle: `Chupa de Cuero`. Sonido: `nugget_cowboy`. Mascota: Hunter.
- **Manu**: Alto, pelo ondulado, gafas rojas fijas, mandarina en mano. Sonido: `allah_akbar`. Mascota: Bichi.
- **Asier**: Toggle `Pelo Largo` / `Rizado Corto`. Sonido: `oh_my_god`. Alerta Android goofy al pulsar Listo. Mascota: Hunter.
- **Marta**: Pelo corto negro. Sin beanie. Toggle: `Gorra Brat`. Sonido: `faaah`. Mascota: Tusa.
- **DJon (DJ)**: Cascos DJ, ensalada César. Sonido: `bing_chilling`. Mascota: Cat.
- **Violeta**: Piel blanca, pelo ondulado naranja, ojos ámbar. Toggle: `Bañador` (torso blanco con bikini/tanga fino rosa). Sonido: `cs_bingo_bongo`. Mascota: Bichi.
- **Lucía**: Chica dulce, ojos marrón clarito. Toggle: Melena larga / pelo corto. Sonido: `harry_potter`. Mascota: Tusa.
- **Eneko**: Rapado pelirrojo con degradado fade. Camisa de vestir blanca. Toggle: Gafas de sol. Sonido: `chinese_ringtone`. Mascota: Hunter.
- **Santi**: Militar con perilla. Toggle: Polo Verde. Sonido: `danger_alarm`. Mascota: Bembo.
- **Alel**: Pelo corto con textura (no calvo). Gafas negras siempre. Toggle: `Camiseta España`. Sonido: `bocina`. Mascota: Bembo.
- **Yago**: Pelo castaño en punta, robusto. Gafas negras siempre. Toggle: `Modo Gaming`. Sonido: `lol_match_found`. Mascota: Cat.
- **Hua**: Chinita, pelo negro liso y largo. Toggle: `Otaku` (anime cosplay). Sonido: `chinese_ringtone`. Mascota: Tusa.

---

## 📁 4. Archivos Clave del Repositorio
- `server.js`: Servidor Node + Socket.IO con routing de eventos, gestión de salas, heats y consensus de mapa.
- `public/js/host.js`: Lógica de la pantalla de TV (lobby, mapa Overworld, podio y selector arcade).
- `public/js/player.js`: Mando móvil, creador de avatares, modo banquillo y switches de gamepad.
- `public/js/avatar-engine.js`: Motor vectorial SVG con avatares, accesorios, ropa y mascotas.
- `public/js/sound-engine.js`: Web Audio API con routing exacto de sonidos meme y control de volumen.
- `public/css/style.css`: Sistema de diseño Cyberpunk / Arcade con botones hápticos 3D y reglas responsive móviles.
- `juego-chavalil.zip`: Paquete completo comprimido con todos los assets, audio y código fuente.

---

## 🚀 5. Tareas Sugeridas para Próximas Sesiones
1. **Despliegue en Máquina Virtual de Google Cloud**:
   - Comprobar latencia WebSockets a través de IP pública o túnel (Cloudflare / ngrok).
   - Validar rendimiento del render Mode 7 y Battlefield en Chrome headless / navegador remoto.
2. **Minijuegos Adicionales (Opcional)**:
   - Minijuego de ritmo musical, esquivar avalanchas o contrarreloj cooperativo si se desea ampliar el catálogo de 7 a 10.
3. **Persistencia de Partidas**:
   - Guardar estadísticas globales de la cuadrilla (quién ha ganado más veces en Mario Kart, Smash o Head Soccer) en SQLite o JSON local.
